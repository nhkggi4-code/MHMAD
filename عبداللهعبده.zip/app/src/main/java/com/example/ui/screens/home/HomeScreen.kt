package com.example.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.entities.CallEntity
import com.example.data.local.entities.ChatEntity
import com.example.data.local.entities.StatusEntity
import com.example.ui.components.LegendAvatar
import com.example.ui.components.LegendShieldBanner
import com.example.ui.components.MessageStatusTicks
import com.example.ui.components.UnreadBadge
import com.example.ui.components.formatCallDuration
import com.example.ui.components.formatChatTimestamp
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.DividerColor
import com.example.ui.theme.LegendGold
import com.example.ui.theme.LegendGoldBright
import com.example.ui.theme.LegendGoldDark
import com.example.ui.theme.LegendGoldGlow
import com.example.ui.theme.LegendGoldLight
import com.example.ui.theme.LegendRed
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueAccent
import com.example.ui.theme.RoyalBlueDark
import com.example.ui.theme.RoyalBlueLight
import com.example.ui.theme.RoyalBlueMedium
import com.example.ui.theme.RoyalMidnight
import com.example.ui.theme.RoyalNavyDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TopBarSurface
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val activeChats by viewModel.activeChats.collectAsStateWithLifecycle()
    val groupChats by viewModel.groupChats.collectAsStateWithLifecycle()
    val calls by viewModel.calls.collectAsStateWithLifecycle()
    val statuses by viewModel.statuses.collectAsStateWithLifecycle()
    val config by viewModel.legendConfig.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isSearchOpen by viewModel.isSearchOpen.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showMenu by remember { mutableStateOf(false) }

    val totalUnread = remember(activeChats) {
        activeChats.sumOf { it.unreadCount }
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .background(TopBarSurface)
                    .border(
                        width = 1.dp,
                        color = DividerColor,
                        shape = RoundedCornerShape(0.dp)
                    )
            ) {
                // Top App Bar
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.testTag("app_title_row")
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(LegendGoldBright, LegendGold)
                                        )
                                    )
                            ) {
                                Text(
                                    text = "👑",
                                    fontSize = 17.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "واتساب الاسطورة محمد",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = LegendGold
                                )
                                Text(
                                    text = "الإصدار الملكي • Sophisticated Dark",
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    },
                    actions = {
                        // Legend Features Shortcut (Crown)
                        IconButton(
                            onClick = { viewModel.navigateTo(AppScreen.LEGEND_FEATURES) },
                            modifier = Modifier.testTag("btn_legend_features")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "إضافات الاسطورة",
                                tint = LegendGoldBright
                            )
                        }

                        // Search Button
                        IconButton(
                            onClick = { viewModel.toggleSearch() },
                            modifier = Modifier.testTag("btn_search_toggle")
                        ) {
                            Icon(
                                imageVector = if (isSearchOpen) Icons.Default.Close else Icons.Default.Search,
                                contentDescription = "بحث",
                                tint = TextPrimary
                            )
                        }

                        // Menu Overflow
                        Box {
                            IconButton(
                                onClick = { showMenu = true },
                                modifier = Modifier.testTag("btn_menu_more")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "خيارات",
                                    tint = TextPrimary
                                )
                            }

                            DropdownMenu(
                                expanded = showMenu,
                                onDismissRequest = { showMenu = false },
                                modifier = Modifier
                                    .background(CardSurfaceDark)
                                    .border(1.dp, LegendGold.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("👑 إضافات الاسطورة محمد", color = LegendGoldBright, fontWeight = FontWeight.Bold)
                                        }
                                    },
                                    onClick = {
                                        showMenu = false
                                        viewModel.navigateTo(AppScreen.LEGEND_FEATURES)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("👥 مجموعة جديدة", color = TextPrimary) },
                                    onClick = {
                                        showMenu = false
                                        viewModel.navigateTo(AppScreen.NEW_GROUP)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("💬 محادثة جديدة برقم", color = TextPrimary) },
                                    onClick = {
                                        showMenu = false
                                        viewModel.navigateTo(AppScreen.NEW_CHAT)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("🔒 قفل الخصوصية والرمز", color = TextPrimary) },
                                    onClick = {
                                        showMenu = false
                                        viewModel.navigateTo(AppScreen.LEGEND_FEATURES)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("⚙️ الإعدادات", color = TextPrimary) },
                                    onClick = {
                                        showMenu = false
                                        viewModel.navigateTo(AppScreen.SETTINGS)
                                    }
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent
                    )
                )

                // Search Bar Expandable
                AnimatedVisibility(
                    visible = isSearchOpen,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.setSearchQuery(it) },
                            placeholder = { Text("بحث في المحادثات والأسماء...", color = TextMuted) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("search_text_field"),
                            shape = RoundedCornerShape(24.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = CardSurfaceDark,
                                unfocusedContainerColor = CardSurfaceDark,
                                focusedBorderColor = LegendGold,
                                unfocusedBorderColor = DividerColor,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                    }
                }

                // Tabs Row
                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = Color.Transparent,
                    contentColor = LegendGold,
                    indicator = { tabPositions ->
                        TabRowDefaults.PrimaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = LegendGoldBright,
                            height = 3.dp
                        )
                    },
                    divider = {
                        HorizontalDivider(color = DividerColor, thickness = 1.dp)
                    }
                ) {
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "المحادثات",
                                    color = if (selectedTabIndex == 0) LegendGoldBright else TextSecondary,
                                    fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                                if (totalUnread > 0) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    UnreadBadge(count = totalUnread)
                                }
                            }
                        },
                        modifier = Modifier.testTag("tab_chats")
                    )

                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "المجموعات",
                                    color = if (selectedTabIndex == 1) LegendGoldBright else TextSecondary,
                                    fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                            }
                        },
                        modifier = Modifier.testTag("tab_groups")
                    )

                    Tab(
                        selected = selectedTabIndex == 2,
                        onClick = { selectedTabIndex = 2 },
                        text = {
                            Text(
                                text = "الحالات",
                                color = if (selectedTabIndex == 2) LegendGoldBright else TextSecondary,
                                fontWeight = if (selectedTabIndex == 2) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                        },
                        modifier = Modifier.testTag("tab_statuses")
                    )

                    Tab(
                        selected = selectedTabIndex == 3,
                        onClick = { selectedTabIndex = 3 },
                        text = {
                            Text(
                                text = "المكالمات",
                                color = if (selectedTabIndex == 3) LegendGoldBright else TextSecondary,
                                fontWeight = if (selectedTabIndex == 3) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                        },
                        modifier = Modifier.testTag("tab_calls")
                    )
                }
            }
        },
        floatingActionButton = {
            when (selectedTabIndex) {
                0 -> {
                    FloatingActionButton(
                        onClick = { viewModel.navigateTo(AppScreen.NEW_CHAT) },
                        containerColor = LegendGold,
                        contentColor = RoyalNavyDark,
                        shape = CircleShape,
                        modifier = Modifier
                            .testTag("fab_new_chat")
                            .shadow(8.dp, CircleShape, spotColor = LegendGoldBright)
                    ) {
                        Icon(imageVector = Icons.Default.Chat, contentDescription = "محادثة جديدة")
                    }
                }
                1 -> {
                    FloatingActionButton(
                        onClick = { viewModel.navigateTo(AppScreen.NEW_GROUP) },
                        containerColor = LegendGold,
                        contentColor = RoyalNavyDark,
                        shape = CircleShape,
                        modifier = Modifier
                            .testTag("fab_new_group")
                            .shadow(8.dp, CircleShape)
                    ) {
                        Icon(imageVector = Icons.Default.Group, contentDescription = "مجموعة جديدة")
                    }
                }
                2 -> {
                    Column(horizontalAlignment = Alignment.End) {
                        FloatingActionButton(
                            onClick = { viewModel.navigateTo(AppScreen.STATUS_CREATOR) },
                            containerColor = CardSurfaceElevated,
                            contentColor = LegendGoldBright,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("fab_text_status")
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "حالة نصية", modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        FloatingActionButton(
                            onClick = { viewModel.navigateTo(AppScreen.STATUS_CREATOR) },
                            containerColor = LegendGold,
                            contentColor = RoyalNavyDark,
                            shape = CircleShape,
                            modifier = Modifier.testTag("fab_camera_status")
                        ) {
                            Icon(imageVector = Icons.Default.CameraAlt, contentDescription = "حالة وسائط")
                        }
                    }
                }
                3 -> {
                    FloatingActionButton(
                        onClick = { viewModel.navigateTo(AppScreen.NEW_CHAT) },
                        containerColor = LegendGold,
                        contentColor = RoyalNavyDark,
                        shape = CircleShape,
                        modifier = Modifier.testTag("fab_new_call")
                    ) {
                        Icon(imageVector = Icons.Default.Call, contentDescription = "مكالمة جديدة")
                    }
                }
            }
        },
        containerColor = RoyalNavyDark,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(RoyalNavyDark)
        ) {
            when (selectedTabIndex) {
                0 -> ChatsTabContent(
                    chats = activeChats.filter {
                        if (searchQuery.isBlank()) true
                        else it.title.contains(searchQuery, ignoreCase = true) || it.lastMessage.contains(searchQuery, ignoreCase = true)
                    },
                    onChatClick = { chatId -> viewModel.openChat(chatId) },
                    onPinToggle = { chatId -> viewModel.togglePinChat(chatId) },
                    onDeleteChat = { chatId -> viewModel.deleteChat(chatId) },
                    onMuteToggle = { chatId -> viewModel.toggleMuteChat(chatId) },
                    onArchiveToggle = { chatId -> viewModel.toggleArchiveChat(chatId) }
                )
                1 -> GroupsTabContent(
                    groups = groupChats.filter {
                        if (searchQuery.isBlank()) true
                        else it.title.contains(searchQuery, ignoreCase = true)
                    },
                    onGroupClick = { chatId -> viewModel.openChat(chatId) },
                    onCreateGroupClick = { viewModel.navigateTo(AppScreen.NEW_GROUP) }
                )
                2 -> StatusTabContent(
                    statuses = statuses,
                    onStatusClick = { status -> viewModel.openStatus(status) },
                    onCreateStatusClick = { viewModel.navigateTo(AppScreen.STATUS_CREATOR) }
                )
                3 -> CallsTabContent(
                    calls = calls,
                    onCallClick = { call ->
                        viewModel.startCall(
                            contactId = call.contactId,
                            contactName = call.contactName,
                            contactAvatarRes = call.contactAvatarRes,
                            isVideo = call.callType == "VIDEO"
                        )
                    },
                    onClearCalls = { viewModel.clearAllCalls() }
                )
            }
        }
    }
}

@Composable
fun ChatsTabContent(
    chats: List<ChatEntity>,
    onChatClick: (String) -> Unit,
    onPinToggle: (String) -> Unit,
    onDeleteChat: (String) -> Unit,
    onMuteToggle: (String) -> Unit,
    onArchiveToggle: (String) -> Unit
) {
    if (chats.isEmpty()) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxSize().padding(32.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Chat,
                    contentDescription = null,
                    tint = LegendGold.copy(alpha = 0.5f),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "لا توجد محادثات حتى الآن",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "اضغط على زر المحادثة بالأسفل لبدء دردشة ملكية جديدة 👑",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(bottom = 80.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    LegendShieldBanner()
                }
            }

            items(chats, key = { it.id }) { chat ->
                ChatItemRow(
                    chat = chat,
                    onClick = { onChatClick(chat.id) },
                    onPinToggle = { onPinToggle(chat.id) },
                    onDeleteChat = { onDeleteChat(chat.id) },
                    onMuteToggle = { onMuteToggle(chat.id) },
                    onArchiveToggle = { onArchiveToggle(chat.id) }
                )
            }
        }
    }
}

@Composable
fun ChatItemRow(
    chat: ChatEntity,
    onClick: () -> Unit,
    onPinToggle: () -> Unit,
    onDeleteChat: () -> Unit,
    onMuteToggle: () -> Unit,
    onArchiveToggle: () -> Unit
) {
    var showItemMenu by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .background(
                if (chat.isPinned && chat.isVipLegend) CardSurfaceDark.copy(alpha = 0.6f)
                else Color.Transparent
            )
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .testTag("chat_item_${chat.id}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            LegendAvatar(
                name = chat.title,
                avatarRes = chat.avatarRes,
                size = 54.dp,
                isOnline = chat.isOnline,
                isVip = chat.isVipLegend
            )

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = chat.title,
                            fontWeight = if (chat.unreadCount > 0 || chat.isVipLegend) FontWeight.Bold else FontWeight.SemiBold,
                            color = if (chat.isVipLegend) LegendGoldBright else TextPrimary,
                            fontSize = 16.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (chat.isMuted) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.VolumeOff,
                                contentDescription = "مكتوم",
                                tint = TextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    Text(
                        text = formatChatTimestamp(chat.lastTimestamp),
                        color = if (chat.unreadCount > 0) LegendGoldBright else TextMuted,
                        fontSize = 12.sp,
                        fontWeight = if (chat.unreadCount > 0) FontWeight.Bold else FontWeight.Normal
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (!chat.isGroup && !chat.isTyping) {
                            MessageStatusTicks(
                                status = chat.lastMessageStatus,
                                modifier = Modifier.padding(end = 4.dp)
                            )
                        }

                        Text(
                            text = if (chat.isTyping) "يكتب الآن..." else chat.lastMessage,
                            color = if (chat.isTyping) LegendGoldBright else if (chat.unreadCount > 0) TextPrimary else TextSecondary,
                            fontSize = 13.sp,
                            fontWeight = if (chat.unreadCount > 0 || chat.isTyping) FontWeight.Medium else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (chat.isPinned) {
                            Icon(
                                imageVector = Icons.Default.PushPin,
                                contentDescription = "مثبتة",
                                tint = LegendGold.copy(alpha = 0.8f),
                                modifier = Modifier
                                    .size(16.dp)
                                    .padding(end = 4.dp)
                            )
                        }

                        UnreadBadge(count = chat.unreadCount)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = DividerColor.copy(alpha = 0.6f), thickness = 0.8.dp)
            }
        }

        // Long press / Action dropdown
        DropdownMenu(
            expanded = showItemMenu,
            onDismissRequest = { showItemMenu = false },
            modifier = Modifier
                .background(CardSurfaceDark)
                .border(1.dp, DividerColor, RoundedCornerShape(8.dp))
        ) {
            DropdownMenuItem(
                text = { Text(if (chat.isPinned) "إلغاء التثبيت" else "تثبيت المحادثة", color = TextPrimary) },
                onClick = {
                    showItemMenu = false
                    onPinToggle()
                }
            )
            DropdownMenuItem(
                text = { Text(if (chat.isMuted) "إلغاء كتم الصوت" else "كتم الإشعارات", color = TextPrimary) },
                onClick = {
                    showItemMenu = false
                    onMuteToggle()
                }
            )
            DropdownMenuItem(
                text = { Text("أرشفة المحادثة", color = TextPrimary) },
                onClick = {
                    showItemMenu = false
                    onArchiveToggle()
                }
            )
            DropdownMenuItem(
                text = { Text("حذف المحادثة", color = LegendRed) },
                onClick = {
                    showItemMenu = false
                    onDeleteChat()
                }
            )
        }
    }
}

@Composable
fun GroupsTabContent(
    groups: List<ChatEntity>,
    onGroupClick: (String) -> Unit,
    onCreateGroupClick: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(bottom = 80.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            // Create Group Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clickable(onClick = onCreateGroupClick)
                    .border(1.dp, RoyalBlueMedium, RoundedCornerShape(12.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(LegendGold, RoyalBlueMedium)
                                )
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "إنشاء مجموعة",
                            tint = RoyalNavyDark
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "إنشاء مجموعة أساطير جديدة 👑",
                            color = LegendGoldBright,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "تواصل مع أكثر من 1024 عضو مع تشفير كامل",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        items(groups, key = { it.id }) { group ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onGroupClick(group.id) }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .testTag("group_item_${group.id}")
            ) {
                LegendAvatar(
                    name = group.title,
                    avatarRes = group.avatarRes,
                    size = 54.dp,
                    isVip = true
                )

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = group.title,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontSize = 16.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Text(
                            text = formatChatTimestamp(group.lastTimestamp),
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = group.lastMessage,
                            color = TextSecondary,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(CardSurfaceElevated)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "👥 ${group.groupMembersCount}",
                                color = RoyalBlueAccent,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusTabContent(
    statuses: List<StatusEntity>,
    onStatusClick: (StatusEntity) -> Unit,
    onCreateStatusClick: () -> Unit
) {
    val myStatus = statuses.find { it.isMine }
    val recentStatuses = statuses.filter { !it.isMine && !it.isViewed }
    val viewedStatuses = statuses.filter { !it.isMine && it.isViewed }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 80.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // My Status Row
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (myStatus != null) onStatusClick(myStatus)
                        else onCreateStatusClick()
                    }
                    .padding(16.dp)
                    .testTag("row_my_status")
            ) {
                Box(contentAlignment = Alignment.BottomEnd) {
                    LegendAvatar(
                        name = "حالتي",
                        avatarRes = R.drawable.img_legend_avatar,
                        size = 56.dp,
                        hasStory = myStatus != null,
                        isStoryViewed = false
                    )

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(LegendGold)
                            .border(2.dp, RoyalNavyDark, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "إضافة حالة",
                            tint = RoyalNavyDark,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = "حالتي",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 16.sp
                    )
                    Text(
                        text = if (myStatus != null) "انقر لعرض حالتك الملكية (${formatChatTimestamp(myStatus.timestamp)})" else "انقر لإضافة تحديث لحالتك",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }

            HorizontalDivider(color = DividerColor, thickness = 1.dp, modifier = Modifier.padding(horizontal = 16.dp))
        }

        // Recent Statuses Header
        if (recentStatuses.isNotEmpty()) {
            item {
                Text(
                    text = "التحديثات الأخيرة",
                    color = LegendGoldBright,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp)
                )
            }

            items(recentStatuses, key = { it.id }) { status ->
                StatusItemRow(status = status, onClick = { onStatusClick(status) })
            }
        }

        // Viewed Statuses Header
        if (viewedStatuses.isNotEmpty()) {
            item {
                Text(
                    text = "التحديثات التي تمت مشاهدتها",
                    color = TextMuted,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp)
                )
            }

            items(viewedStatuses, key = { it.id }) { status ->
                StatusItemRow(status = status, onClick = { onStatusClick(status) })
            }
        }
    }
}

@Composable
fun StatusItemRow(
    status: StatusEntity,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .testTag("status_item_${status.id}")
    ) {
        LegendAvatar(
            name = status.authorName,
            avatarRes = status.authorAvatarRes,
            size = 54.dp,
            hasStory = true,
            isStoryViewed = status.isViewed
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = status.authorName,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = formatChatTimestamp(status.timestamp),
                color = TextSecondary,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun CallsTabContent(
    calls: List<CallEntity>,
    onCallClick: (CallEntity) -> Unit,
    onClearCalls: () -> Unit
) {
    if (calls.isEmpty()) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxSize().padding(32.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Phone,
                    contentDescription = null,
                    tint = LegendGold.copy(alpha = 0.5f),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "سجل المكالمات فارغ",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "أجرِ مكالمات صوتية ومرئية عالية الدقة بنقرة واحدة 📞",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(bottom = 80.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = "المكالمات الحديثة",
                        color = LegendGoldBright,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    Text(
                        text = "مسح الكل",
                        color = TextMuted,
                        fontSize = 12.sp,
                        modifier = Modifier.clickable(onClick = onClearCalls)
                    )
                }
            }

            items(calls, key = { it.id }) { call ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onCallClick(call) }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .testTag("call_item_${call.id}")
                ) {
                    LegendAvatar(
                        name = call.contactName,
                        avatarRes = call.contactAvatarRes,
                        size = 52.dp,
                        isVip = call.contactName.contains("الاسطورة")
                    )

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = call.contactName,
                            fontWeight = FontWeight.Bold,
                            color = if (call.direction == "MISSED") LegendRed else TextPrimary,
                            fontSize = 16.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = when (call.direction) {
                                    "INCOMING" -> Icons.Default.CallReceived
                                    "OUTGOING" -> Icons.Default.CallMade
                                    else -> Icons.Default.CallReceived
                                },
                                contentDescription = null,
                                tint = when (call.direction) {
                                    "MISSED" -> LegendRed
                                    "INCOMING" -> OnlineGreen
                                    else -> RoyalBlueAccent
                                },
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${formatChatTimestamp(call.timestamp)}${if (call.durationSeconds > 0) " • ${formatCallDuration(call.durationSeconds)}" else ""}",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = { onCallClick(call) },
                        modifier = Modifier.testTag("btn_call_action_${call.id}")
                    ) {
                        Icon(
                            imageVector = if (call.callType == "VIDEO") Icons.Default.Videocam else Icons.Default.Call,
                            contentDescription = "اتصال",
                            tint = LegendGoldBright
                        )
                    }
                }
            }
        }
    }
}
