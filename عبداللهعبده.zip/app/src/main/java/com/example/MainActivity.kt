package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.auth.OtpVerificationScreen
import com.example.ui.screens.auth.PhoneLoginScreen
import com.example.ui.screens.auth.WelcomeAuthScreen
import com.example.ui.screens.call.CallScreen
import com.example.ui.screens.chat.ChatDetailScreen
import com.example.ui.screens.group.NewChatScreen
import com.example.ui.screens.group.NewGroupScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.legend.LegendFeaturesScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.status.StatusCreatorScreen
import com.example.ui.screens.status.StatusViewerScreen
import com.example.ui.theme.LegendTheme
import com.example.ui.theme.RoyalNavyDark
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.ChatViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val chatViewModel: ChatViewModel = viewModel()

            LegendTheme {
                // Ensure RTL Layout direction for Arabic WhatsApp experience
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = RoyalNavyDark
                    ) {
                        LegendAppNavigation(viewModel = chatViewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun LegendAppNavigation(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val activeCall by viewModel.activeCall.collectAsStateWithLifecycle()

    // Handle System Back navigation
    BackHandler(enabled = currentScreen != AppScreen.HOME && currentScreen != AppScreen.AUTH_WELCOME) {
        when (currentScreen) {
            AppScreen.CHAT_DETAIL -> viewModel.closeChat()
            AppScreen.ACTIVE_CALL -> viewModel.endCall()
            AppScreen.STATUS_VIEWER, AppScreen.STATUS_CREATOR -> viewModel.closeStatus()
            AppScreen.AUTH_OTP -> viewModel.navigateTo(AppScreen.AUTH_PHONE)
            AppScreen.AUTH_PHONE -> viewModel.navigateTo(AppScreen.AUTH_WELCOME)
            else -> viewModel.navigateTo(AppScreen.HOME)
        }
    }

    // Call Screen overlays everything when active
    if (activeCall != null && currentScreen == AppScreen.ACTIVE_CALL) {
        CallScreen(viewModel = viewModel, modifier = modifier)
    } else {
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                    slideOutHorizontally { width -> -width } + fadeOut()
                )
            },
            label = "screen_transition"
        ) { targetScreen ->
            when (targetScreen) {
                AppScreen.HOME -> HomeScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.CHAT_DETAIL -> ChatDetailScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.ACTIVE_CALL -> CallScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.STATUS_VIEWER -> StatusViewerScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.STATUS_CREATOR -> StatusCreatorScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.LEGEND_FEATURES -> LegendFeaturesScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.SETTINGS -> SettingsScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.PROFILE -> SettingsScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.ARCHIVED_CHATS -> HomeScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.NEW_CHAT -> NewChatScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.NEW_GROUP -> NewGroupScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.AUTH_WELCOME -> WelcomeAuthScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.AUTH_PHONE -> PhoneLoginScreen(viewModel = viewModel, modifier = modifier)
                AppScreen.AUTH_OTP -> OtpVerificationScreen(viewModel = viewModel, modifier = modifier)
            }
        }
    }
}
